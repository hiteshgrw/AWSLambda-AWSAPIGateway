import pymysql
import sys


def save_events(event):
    conn = pymysql.connect(host='40.122.204.90', database='regdb', user='MySql', password='')
    cr = conn.cursor()
    cr.execute('SELECT * from reg_tbl')
    rows = cr.fetchall()
    return {
        'statusCode': 200,
        'body': json.dumps(rows)
    }


def main(event, context):
    save_events(event)

